import os

# Default admin credentials
ADMIN_USERNAME = 'ASH'
ADMIN_PASSWORD = 'Joshua091003@'

# Default settings
DEFAULT_SETTINGS = {
    'default_expiration_days': '30',
    'site_name': 'AshxDeath Panel',
    'max_login_attempts': '5',
    'login_lockout_time_minutes': '15'
}
